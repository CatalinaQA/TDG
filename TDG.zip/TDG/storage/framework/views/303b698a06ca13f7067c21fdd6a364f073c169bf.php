<?php $__env->startSection('template_title'); ?>
    <?php echo e($program->name ?? 'Información Programa'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Información Programa</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('programs.index')); ?>"> Atrás</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Nombre facultad:</strong>
                            <?php echo e($program->faculty->faculty_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre coordinación:</strong>
                            <?php echo e($program->coordination->coordination_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre programa:</strong>
                            <?php echo e($program->program_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Categoría:</strong>
                            <?php echo e($program->program_category); ?>

                        </div>
                        <div class="form-group">
                            <strong>Registro SNIES:</strong>
                            <?php echo e($program->snies_register); ?>

                        </div>
                        <div class="form-group">
                            <strong>Teléfono:</strong>
                            <?php echo e($program->program_phone); ?>

                        </div>
                        <div class="form-group">
                            <strong>Estado:</strong>
                            <?php echo e(($program->status == 1) ? 'Activo' : 'Inactivo'); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\proyectogrado\resources\views/program/show.blade.php ENDPATH**/ ?>