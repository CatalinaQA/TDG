<?php $__env->startSection('template_title'); ?>
    Asignaturas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <?php echo e(__('Asignaturas')); ?>

                            </span>

                             <div class="float-right">
                                <a href="<?php echo e(route('subjects.create')); ?>" class="btn btn-primary btn-sm float-right"  data-placement="left">
                                  <?php echo e(__('Agregar')); ?>

                                </a>
                              </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <span class="card-title"><b>Buscar asignaturas</b></span>
                        <form method="GET" action="<?php echo e(route('subjects.index')); ?>"  role="form">
                            <?php echo $__env->make('subject.search_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </form>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        <th>Nombre facultad</th>
										<th>Nombre coordinación</th>
										<th>Nombre programa</th>
										<th>Nombre area</th>
										<th>Código asignatura</th>
										<th>Nombre asignatura</th>
										<th>Créditos asignatura</th>
										<th>Nivel asignatura</th>
										<th>Código pre-requisito 1</th>
										<th>Nombre pre-requisito 1</th>
										<th>Código pre-requisito 2</th>
										<th>Nombre pre-requisito 2</th>
										<th>Código co-requisito 1</th>
										<th>Nombre co-requisito 1</th>
										<th>Código co-requisito 2</th>
										<th>Nombre co-requisito 2</th>
										<th>Estado</th>

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($subject->faculty->faculty_name); ?></td>
											<td><?php echo e($subject->coordination->coordination_name); ?></td>
											<td><?php echo e($subject->program->program_name); ?></td>
											<td><?php echo e($subject->area->area_name); ?></td>
											<td><?php echo e($subject->subject_code); ?></td>
											<td><?php echo e($subject->subject_name); ?></td>
											<td><?php echo e($subject->subject_credits); ?></td>
											<td><?php echo e($subject->subject_level); ?></td>
											<td><?php echo e($subject->prerequisite_code_1); ?></td>
											<td><?php echo e($subject->prerequisite_name_1); ?></td>
											<td><?php echo e($subject->prerequisite_code_2); ?></td>
											<td><?php echo e($subject->prerequisite_name_2); ?></td>
											<td><?php echo e($subject->corequisite_code_1); ?></td>
											<td><?php echo e($subject->corequisite_name_1); ?></td>
											<td><?php echo e($subject->corequisite_code_2); ?></td>
											<td><?php echo e($subject->corequisite_name_2); ?></td>
											<td><?php echo e(($subject->status == 1) ? 'Activo' : 'Inactivo'); ?></td>

                                            <td>
                                                <a class="btn btn-sm btn-primary " href="<?php echo e(route('subjects.show',$subject->id)); ?>"><i class="fa fa-fw fa-eye"></i> Mostrtar</a>
                                                <a class="btn btn-sm btn-success" href="<?php echo e(route('subjects.edit',$subject->id)); ?>"><i class="fa fa-fw fa-edit"></i> Editar</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php echo $subjects->links(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TDG\TDG\resources\views/subject/index.blade.php ENDPATH**/ ?>