<?php $__env->startSection('template_title'); ?>
    Programación Académica
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <?php echo e(__('Programación Académica')); ?>

                            </span>
                        </div>
                    </div>
                    <div class="card-body">
                        <span class="card-title"><b>Buscar programación</b></span>
                        <form method="GET" action="<?php echo e(route('schedules.index')); ?>"  role="form">
                            <?php echo $__env->make('schedule.search_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </form>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        <th>Sede</th>
                                        <th>Código</th>
                                        <th>Groupo</th>
                                        <th>Nombre</th>
                                        <th>Detalle</th>
                                        <th>Día</th>
                                        <th>Hora</th>
                                        <th>Aula</th>
                                        <th>Actividad</th>
                                        <th>Nivel estudio</th>
                                        <th>Créditos</th>
                                        <th>Capacidad aula</th>
                                        <th>Capacidad programada</th>
                                        <th>Matriculados</th>
                                        <th>Programa</th>
                                        <th>Plan</th>
                                        <th>Total horas</th>
                                        <th>Horas asesorías</th>
                                        <th>Horas evaluación</th>
                                        <th>Cédula docente</th>
                                        <th>Nombre docente</th>
                                        <th>Tipo vinculación docente</th>
                                        <th>Área</th>
                                        <th>Coordinador</th>
                                        <th>Observaciones</th>
                                        <th>Estado</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($campus[$schedule->campus]); ?></td>
                                            <td><?php echo e($schedule->subject->subject_code); ?></td>
                                            <td><?php echo e($schedule->group); ?></td>
                                            <td><?php echo e($schedule->subject->subject_name); ?></td>
                                            <td><?php echo e($schedule->detail); ?></td>
                                            <td><?php echo e($days[$schedule->day]); ?></td>
                                            <td><?php echo e($schedule->start_hour . ':' . $schedule->start_minute . '-' . $schedule->end_hour . ':' . $schedule->end_minute); ?></td>
                                            <td><?php echo e($schedule->classroom); ?></td>
                                            <td><?php echo e($schedule->activity); ?></td>
                                            <td><?php echo e($schedule->subject->subject_level); ?></td>
                                            <td><?php echo e($schedule->subject->credits); ?></td>
                                            <td><?php echo e($schedule->classroom_capacity); ?></td>
                                            <td><?php echo e($schedule->scheduled_capacity); ?></td>
                                            <td><?php echo e($schedule->enrolled); ?></td>
                                            <td><?php echo e($schedule->program->program_name); ?></td>
                                            <td><?php echo e($schedule->plan); ?></td>
                                            <td><?php echo e($schedule->total_hours); ?></td>
                                            <td><?php echo e($schedule->consultancies); ?></td>
                                            <td><?php echo e($schedule->evaluation_hours); ?></td>
                                            <td><?php echo e(($schedule->teacher != "") ? $schedule->teachers->document : ""); ?></td>
                                            <td><?php echo e(($schedule->teacher != "") ? $schedule->teachers->name : ""); ?></td>
                                            <td><?php echo e(($schedule->teacher != "") ? $schedule->teachers->contract_type : ""); ?></td>
                                            <td><?php echo e($schedule->area->area_name); ?></td>
                                            <td><?php echo e($schedule->area->user->name); ?></td>
                                            <td><?php echo e($schedule->observations); ?></td>
                                            <td><?php echo e($schedule->status); ?></td>
                                            <td>
                                                <a class="btn btn-sm btn-primary " href="<?php echo e(route('schedules.show',$schedule->id)); ?>"><i class="fa fa-fw"></i> Mostrar</a>
                                                <?php if($role !== 'admisiones'): ?>
                                                    <a class="btn btn-sm btn-success" href="<?php echo e(route('schedules.edit',$schedule->id)); ?>"><i class="fa fa-fw"></i> Editar</a>
                                                <?php endif; ?>
                                                <?php if($role !== 'admisiones' || $role !== 'admin'): ?>
                                                    <button id="anwer-btn" type="button" class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#answer" data-id="<?php echo e($schedule->id); ?>" data-observations="<?php echo e($schedule->observations); ?>">Responder</button>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php echo $schedules->links(); ?>

            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="answer" tabindex="-1" aria-labelledby="answerLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="answerLabel">Responder</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="answers" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="box box-info padding-1">
                            <div class="box-body">
                                <div class="form-group">
                                    <?php echo e(Form::hidden('id', '')); ?>

                                    <?php echo e(Form::label('Observaciones')); ?>

                                    <?php echo e(Form::text('observations', "", ['class' => 'form-control' . ($errors->has('observations') ? ' is-invalid' : ''), 'placeholder' => 'Observaciones', 'required' => 'required'])); ?>

                                    <?php echo $errors->first('observations', '<div class="invalid-feedback">:message</p>'); ?>

                                </div>
                            </div>
                            <br>
                            <button class="btn btn-primary btn-sm float-left" type="submit" name="action" value="accept">Aceptar</button>
                            <button class="btn btn-danger btn-sm float-right" type="submit" name="action" value="rejected">Rechazar</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function () {
            $('body').on('click', '#anwer-btn', function (event) {
                event.preventDefault();
                var id           = $(this).data('id');
                var observations = $(this).data('observations');

                $('[name="observations"]').val(observations);
                $('[name="id"]').val(id);
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\proyectogrado\resources\views/schedule/index.blade.php ENDPATH**/ ?>