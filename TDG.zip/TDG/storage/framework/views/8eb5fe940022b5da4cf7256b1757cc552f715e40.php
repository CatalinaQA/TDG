<?php $__env->startSection('template_title'); ?>
    Curriculum Matrix
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <?php echo e(__('Curriculum Matrix')); ?>

                            </span>

                             <div class="float-right">
                                <a href="<?php echo e(route('curriculum_matrices.create')); ?>" class="btn btn-primary btn-sm float-right"  data-placement="left">
                                  <?php echo e(__('Create New')); ?>

                                </a>
                              </div>
                        </div>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        <th>No</th>
                                        
										<th>Faculty Id</th>
										<th>Coordination Id</th>
										<th>Program Id</th>
										<th>Course Name</th>
										<th>Course Credits</th>
										<th>Course Level</th>
										<th>Prerequisite Code 1</th>
										<th>Prerequisite Name 1</th>
										<th>Prerequisite Code 2</th>
										<th>Prerequisite Name 2</th>
										<th>Corequisite Code 1</th>
										<th>Corequisite Name 1</th>
										<th>Corequisite Code 2</th>
										<th>Corequisite Name 2</th>

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $curriculumMatrices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curriculumMatrix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$i); ?></td>
                                            
											<td><?php echo e($curriculumMatrix->faculty_id); ?></td>
											<td><?php echo e($curriculumMatrix->coordination_id); ?></td>
											<td><?php echo e($curriculumMatrix->program_id); ?></td>
											<td><?php echo e($curriculumMatrix->course_name); ?></td>
											<td><?php echo e($curriculumMatrix->course_credits); ?></td>
											<td><?php echo e($curriculumMatrix->course_level); ?></td>
											<td><?php echo e($curriculumMatrix->prerequisite_code_1); ?></td>
											<td><?php echo e($curriculumMatrix->prerequisite_name_1); ?></td>
											<td><?php echo e($curriculumMatrix->prerequisite_code_2); ?></td>
											<td><?php echo e($curriculumMatrix->prerequisite_name_2); ?></td>
											<td><?php echo e($curriculumMatrix->corequisite_code_1); ?></td>
											<td><?php echo e($curriculumMatrix->corequisite_name_1); ?></td>
											<td><?php echo e($curriculumMatrix->corequisite_code_2); ?></td>
											<td><?php echo e($curriculumMatrix->corequisite_name_2); ?></td>

                                            <td>
                                                <form action="<?php echo e(route('curriculum_matrices.destroy',$curriculumMatrix->id)); ?>" method="POST">
                                                    <a class="btn btn-sm btn-primary " href="<?php echo e(route('curriculum_matrices.show',$curriculumMatrix->id)); ?>"><i class="fa fa-fw fa-eye"></i> Show</a>
                                                    <a class="btn btn-sm btn-success" href="<?php echo e(route('curriculum_matrices.edit',$curriculumMatrix->id)); ?>"><i class="fa fa-fw fa-edit"></i> Edit</a>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-fw fa-trash"></i> Delete</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php echo $curriculumMatrices->links(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\proyectogrado\resources\views/curriculum_matrix/index.blade.php ENDPATH**/ ?>