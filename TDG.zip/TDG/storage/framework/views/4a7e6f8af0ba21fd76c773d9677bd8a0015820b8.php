<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('Nombre facultad')); ?>

            <?php echo e(Form::select('faculty_id', $faculties, $coordination->faculty_id, ['class' => 'form-control' . ($errors->has('faculty_id') ? ' is-invalid' : ''), 'placeholder' => 'Nombre facultad'])); ?>

            <?php echo $errors->first('faculty_id', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Nombre coordinación')); ?>

            <?php echo e(Form::text('coordination_name', $coordination->coordination_name, ['class' => 'form-control' . ($errors->has('coordination_name') ? ' is-invalid' : ''), 'placeholder' => 'Nombre coordinación'])); ?>

            <?php echo $errors->first('coordination_name', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Nombre profesional')); ?>

            <?php echo e(Form::select('coordinator', $coordinators, $coordination->coordinator,['class' => 'form-control' . ($errors->has('coordinator') ? ' is-invalid' : ''), 'placeholder' => 'Nombre profesional'])); ?>

            <?php echo $errors->first('coordinator', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Teléfono')); ?>

            <?php echo e(Form::text('professional_phone', $coordination->professional_phone, ['class' => 'form-control' . ($errors->has('professional_phone') ? ' is-invalid' : ''), 'placeholder' => 'Teléfono'])); ?>

            <?php echo $errors->first('professional_phone', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Nombre auxiliar')); ?>

            <?php echo e(Form::text('coordination_auxiliar_name', $coordination->coordination_auxiliar_name, ['class' => 'form-control' . ($errors->has('coordination_auxiliar_name') ? ' is-invalid' : ''), 'placeholder' => 'Nombre auxiliar'])); ?>

            <?php echo $errors->first('coordination_auxiliar_name', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Email auxiliar')); ?>

            <?php echo e(Form::email('coordination_auxiliar_email', $coordination->coordination_auxiliar_email, ['class' => 'form-control' . ($errors->has('coordination_auxiliar_email') ? ' is-invalid' : ''), 'placeholder' => 'Email auxiliar'])); ?>

            <?php echo $errors->first('coordination_auxiliar_email', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Teléfono auxiliar')); ?>

            <?php echo e(Form::text('coordination_auxiliar_phone', $coordination->coordination_auxiliar_phone, ['class' => 'form-control' . ($errors->has('coordination_auxiliar_phone') ? ' is-invalid' : ''), 'placeholder' => 'Teléfono auxiliar'])); ?>

            <?php echo $errors->first('coordination_auxiliar_phone', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Estado')); ?>

            <?php echo e(Form::select('status', [1=>'Activo', 0=>'Inactivo'], ($coordination->status) ?? 1, ['class' => 'form-control' . ($errors->has('status') ? ' is-invalid' : ''), 'placeholder' => 'Estado'])); ?>

            <?php echo $errors->first('status', '<div class="invalid-feedback">:message</p>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <br>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </div>
</div><?php /**PATH D:\laragon\www\proyectogrado\resources\views/coordination/form.blade.php ENDPATH**/ ?>