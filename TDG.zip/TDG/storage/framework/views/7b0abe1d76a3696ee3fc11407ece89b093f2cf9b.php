<div class="row g-3">
    <div class="col-sm-2">
        <?php echo e(Form::label('Sede')); ?>

        <?php echo e(Form::select('campus', $campus, $request['campus'], ['class' => 'form-control', 'placeholder' => 'Sede'])); ?>

    </div>
    <div class="col-sm-2">
        <?php echo e(Form::label('Código ó nombre asignatura')); ?>

        <?php echo e(Form::text('subject_name', $request['subject_name'], ['class' => 'form-control', 'placeholder' => 'Código o nombre asignatura'])); ?>

    </div>
    <div class="col-sm-2">
        <?php echo e(Form::label('Groupo')); ?>

        <?php echo e(Form::number('group',$request['group'], ['class' => 'form-control', 'placeholder' => 'Groupo'])); ?>

    </div>
    <div class="col-sm-2">
        <?php echo e(Form::label('Día')); ?>

        <?php echo e(Form::select('day', $days, $request['day'], ['class' => 'form-control', 'placeholder' => 'Día'])); ?>

    </div>
    <div class="col-sm-2">
        <?php echo e(Form::label('Hora inicio')); ?>

        <?php echo e(Form::time('start_hour',$request['start_hour'], ['class' => 'form-control', 'placeholder' => 'Hora inicio'])); ?>

    </div>
    <div class="col-sm-2">
        <?php echo e(Form::label('Hora final')); ?>

        <?php echo e(Form::time('end_hour',$request['end_hour'], ['class' => 'form-control', 'placeholder' => 'Hora final'])); ?>

    </div>
</div>
<br>
<div class="row g-3">
    <div class="col-sm-2">
        <?php echo e(Form::label('Aula')); ?>

        <?php echo e(Form::text('classroom', $request['classroom'], ['class' => 'form-control', 'placeholder' => 'Aula'])); ?>

    </div>
    <div class="col-sm-2">
        <?php echo e(Form::label('Actividad')); ?>

        <?php echo e(Form::text('activity', $request['activity'], ['class' => 'form-control', 'placeholder' => 'Actividad'])); ?>

    </div>
    <div class="col-sm-2">
        <?php echo e(Form::label('Nivel estudio')); ?>

        <?php echo e(Form::number('subject_level',$request['subject_level'], ['class' => 'form-control', 'placeholder' => 'Nivel estudio'])); ?>

    </div>
    <div class="col-sm-2">
        <?php echo e(Form::label('Nombre programa')); ?>

        <?php echo e(Form::select('program_id', $programs, $request['program_id'], ['class' => 'form-control', 'placeholder' => 'Nombre programa'])); ?>

    </div>
    <div class="col-sm-2">
        <?php echo e(Form::label('Documento ó nombre docente')); ?>

        <?php echo e(Form::text('teacher_name', $request['teacher_name'], ['class' => 'form-control', 'placeholder' => 'Documento ó nombre docente'])); ?>

    </div>    
</div>
<br>
<div class="row g-3">
    <div class="col-sm-4">
        <?php echo e(Form::select('area_id', $areas, $request['area_id'], ['class' => 'form-control', 'placeholder' => 'Nombre área'])); ?>

    </div>
    <div class="col-sm-4">
        <?php echo e(Form::text('coordinator_name', $request['coordinator_name'], ['class' => 'form-control', 'placeholder' => 'Nombre coordinador area'])); ?>

    </div>
    <div class="col-sm">
        <button type="submit" class="btn btn-primary">Buscar</button>
    </div>
</div><?php /**PATH D:\laragon\www\proyectogrado\resources\views/schedule/search_form.blade.php ENDPATH**/ ?>