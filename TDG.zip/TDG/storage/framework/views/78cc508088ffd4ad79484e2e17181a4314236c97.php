<?php $__env->startSection('template_title'); ?>
    <?php echo e($curriculumMatrix->name ?? 'Show Curriculum Matrix'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Show Curriculum Matrix</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('curriculum_matrices.index')); ?>"> Back</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Faculty Id:</strong>
                            <?php echo e($curriculumMatrix->faculty->faculty_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Coordination Id:</strong>
                            <?php echo e($curriculumMatrix->coordination->coordination_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Program Id:</strong>
                            <?php echo e($curriculumMatrix->program->program_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Course Name:</strong>
                            <?php echo e($curriculumMatrix->course_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Course Credits:</strong>
                            <?php echo e($curriculumMatrix->course_credits); ?>

                        </div>
                        <div class="form-group">
                            <strong>Course Level:</strong>
                            <?php echo e($curriculumMatrix->course_level); ?>

                        </div>
                        <div class="form-group">
                            <strong>Prerequisite Code 1:</strong>
                            <?php echo e($curriculumMatrix->prerequisite_code_1); ?>

                        </div>
                        <div class="form-group">
                            <strong>Prerequisite Name 1:</strong>
                            <?php echo e($curriculumMatrix->prerequisite_name_1); ?>

                        </div>
                        <div class="form-group">
                            <strong>Prerequisite Code 2:</strong>
                            <?php echo e($curriculumMatrix->prerequisite_code_2); ?>

                        </div>
                        <div class="form-group">
                            <strong>Prerequisite Name 2:</strong>
                            <?php echo e($curriculumMatrix->prerequisite_name_2); ?>

                        </div>
                        <div class="form-group">
                            <strong>Corequisite Code 1:</strong>
                            <?php echo e($curriculumMatrix->corequisite_code_1); ?>

                        </div>
                        <div class="form-group">
                            <strong>Corequisite Name 1:</strong>
                            <?php echo e($curriculumMatrix->corequisite_name_1); ?>

                        </div>
                        <div class="form-group">
                            <strong>Corequisite Code 2:</strong>
                            <?php echo e($curriculumMatrix->corequisite_code_2); ?>

                        </div>
                        <div class="form-group">
                            <strong>Corequisite Name 2:</strong>
                            <?php echo e($curriculumMatrix->corequisite_name_2); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\proyectogrado\resources\views/curriculum_matrix/show.blade.php ENDPATH**/ ?>