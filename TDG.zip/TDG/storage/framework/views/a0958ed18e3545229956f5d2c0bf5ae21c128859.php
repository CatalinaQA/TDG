<?php $__env->startSection('template_title'); ?>
    Docentes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <?php echo e(__('Docentes')); ?>

                            </span>
                        </div>
                    </div>
                    <div class="card-body">
                        <span class="card-title"><b>Buscar docentes</b></span>
                        <form method="GET" action="<?php echo e(route('teachers.index')); ?>"  role="form">
                            <?php echo $__env->make('teacher.search_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </form>
                    </div>
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e($message); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead class="thead">
                                    <tr>
                                        <th>Nombre</th>
										<th>Documento</th>
										<th>Email</th>
										<th>Número móvil</th>
										<th>Tipo de contrato</th>
										<th>Estado</th>

                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($teacher->name); ?></td>
											<td><?php echo e($teacher->document); ?></td>
											<td><?php echo e($teacher->email); ?></td>
											<td><?php echo e($teacher->cellphone_number); ?></td>
											<td><?php echo e($teacher->contract_type); ?></td>
											<td><?php echo e(($teacher->status == 1) ? 'Activo' : 'Inactivo'); ?></td>

                                            <td>
                                                <form action="<?php echo e(route('teachers.destroy',$teacher->id)); ?>" method="POST">
                                                    <a class="btn btn-sm btn-primary " href="<?php echo e(route('teachers.show',$teacher->id)); ?>"><i class="fa fa-fw fa-eye"></i> Mostrar</a>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <?php echo $teachers->links(); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TDG\TDG\resources\views/teacher/index.blade.php ENDPATH**/ ?>