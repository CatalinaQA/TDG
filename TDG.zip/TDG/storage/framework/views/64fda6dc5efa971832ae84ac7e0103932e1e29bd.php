<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('Sede')); ?>

            <?php echo e(Form::text('campus', $campus[$schedule->campus], ['class' => 'form-control' . ($errors->has('campus') ? ' is-invalid' : ''), 'placeholder' => 'Sede', 'disabled'])); ?>

            <?php echo $errors->first('campus', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Código')); ?>

            <?php echo e(Form::text('subject_code', $schedule->subject->subject_code, ['class' => 'form-control' . ($errors->has('subject_code') ? ' is-invalid' : ''), 'placeholder' => 'Código', 'disabled'])); ?>

            <?php echo $errors->first('subject_code', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Groupo')); ?>

            <?php echo e(Form::number('group', $schedule->group, ['class' => 'form-control' . ($errors->has('group') ? ' is-invalid' : ''), 'placeholder' => 'Groupo'])); ?>

            <?php echo $errors->first('group', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Nombre')); ?>

            <?php echo e(Form::text('subject_name', $schedule->subject->subject_name, ['class' => 'form-control' . ($errors->has('subject_name') ? ' is-invalid' : ''), 'placeholder' => 'Nombre', 'disabled'])); ?>

            <?php echo $errors->first('area_id', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Detalle')); ?>

            <?php echo e(Form::text('detail', $schedule->detail, ['class' => 'form-control' . ($errors->has('detail') ? ' is-invalid' : ''), 'placeholder' => 'Detalle', 'disabled'])); ?>

            <?php echo $errors->first('detail', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Día')); ?>

            <?php echo e(Form::select('day', $days, $schedule->day, ['class' => 'form-control' . ($errors->has('day') ? ' is-invalid' : ''), 'placeholder' => 'Día'])); ?>

            <?php echo $errors->first('day', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Hora inicio')); ?>

            <?php echo e(Form::time('start_hour', $start_hour, ['class' => 'form-control' . ($errors->has('start_hour') ? ' is-invalid' : ''), 'placeholder' => 'Hora inicio'])); ?>

            <?php echo $errors->first('start_hour', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Hora final')); ?>

            <?php echo e(Form::time('end_hour', $end_hour, ['class' => 'form-control' . ($errors->has('end_hour') ? ' is-invalid' : ''), 'placeholder' => 'Hora final'])); ?>

            <?php echo $errors->first('end_hour', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Aula')); ?>

            <?php echo e(Form::text('classroom', $schedule->classroom, ['class' => 'form-control' . ($errors->has('classroom') ? ' is-invalid' : ''), 'placeholder' => 'Aula'])); ?>

            <?php echo $errors->first('classroom', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Actividad')); ?>

            <?php echo e(Form::text('activity', $schedule->activity, ['class' => 'form-control' . ($errors->has('activity') ? ' is-invalid' : ''), 'placeholder' => 'Actividad', 'disabled'])); ?>

            <?php echo $errors->first('activity', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Nivel estudio')); ?>

            <?php echo e(Form::text('subject_level', $schedule->subject->subject_level, ['class' => 'form-control' . ($errors->has('subject_level') ? ' is-invalid' : ''), 'placeholder' => 'Nivel estudio', 'disabled'])); ?>

            <?php echo $errors->first('subject_level', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Créditos')); ?>

            <?php echo e(Form::text('credits', $schedule->subject->credits, ['class' => 'form-control' . ($errors->has('credits') ? ' is-invalid' : ''), 'placeholder' => 'Créditos', 'disabled'])); ?>

            <?php echo $errors->first('credits', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Capacidad aula')); ?>

            <?php echo e(Form::number('classroom_capacity', $schedule->classroom_capacity, ['class' => 'form-control' . ($errors->has('classroom_capacity') ? ' is-invalid' : ''), 'placeholder' => 'Capacidad aula'])); ?>

            <?php echo $errors->first('classroom_capacity', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Capacidad programada')); ?>

            <?php echo e(Form::number('scheduled_capacity', $schedule->scheduled_capacity, ['class' => 'form-control' . ($errors->has('scheduled_capacity') ? ' is-invalid' : ''), 'placeholder' => 'Capacidad programada'])); ?>

            <?php echo $errors->first('scheduled_capacity', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Matriculados')); ?>

            <?php echo e(Form::text('enrolled', $schedule->enrolled, ['class' => 'form-control' . ($errors->has('enrolled') ? ' is-invalid' : ''), 'placeholder' => 'Matriculados', 'disabled'])); ?>

            <?php echo $errors->first('enrolled', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Programa')); ?>

            <?php echo e(Form::text('program_name', $schedule->program->program_name, ['class' => 'form-control' . ($errors->has('program_name') ? ' is-invalid' : ''), 'placeholder' => 'Programa', 'disabled'])); ?>

            <?php echo $errors->first('program_name', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Plan')); ?>

            <?php echo e(Form::text('plan', $schedule->plan, ['class' => 'form-control' . ($errors->has('plan') ? ' is-invalid' : ''), 'placeholder' => 'Plan', 'disabled'])); ?>

            <?php echo $errors->first('plan', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Total horas')); ?>

            <?php echo e(Form::text('total_hours', $schedule->total_hours, ['class' => 'form-control' . ($errors->has('total_hours') ? ' is-invalid' : ''), 'placeholder' => 'Total horas', 'disabled'])); ?>

            <?php echo $errors->first('total_hours', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Horas asesorías')); ?>

            <?php echo e(Form::number('consultancies', $schedule->consultancies, ['class' => 'form-control' . ($errors->has('consultancies') ? ' is-invalid' : ''), 'placeholder' => 'Horas asesorías'])); ?>

            <?php echo $errors->first('consultancies', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Horas evaluación')); ?>

            <?php echo e(Form::number('evaluation_hours', $schedule->evaluation_hours, ['class' => 'form-control' . ($errors->has('evaluation_hours') ? ' is-invalid' : ''), 'placeholder' => 'Horas evaluación'])); ?>

            <?php echo $errors->first('evaluation_hours', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Docente')); ?>

            <?php echo e(Form::select('teacher', $teachers, ($schedule->teacher != "") ? $schedule->teachers->id : "", ['class' => 'form-control' . ($errors->has('teacher') ? ' is-invalid' : ''), 'placeholder' => 'Docente'])); ?>

            <?php echo $errors->first('teacher', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Área')); ?>

            <?php echo e(Form::text('area_name', $schedule->area->area_name, ['class' => 'form-control' . ($errors->has('area_name') ? ' is-invalid' : ''), 'placeholder' => 'Área', 'disabled'])); ?>

            <?php echo $errors->first('area_name', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Coordinador')); ?>

            <?php echo e(Form::text('coordinator_name', $schedule->area->coordinator_name, ['class' => 'form-control' . ($errors->has('coordinator_name') ? ' is-invalid' : ''), 'placeholder' => 'Coordinador', 'disabled'])); ?>

            <?php echo $errors->first('coordinator_name', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Observaciones')); ?>

            <?php echo e(Form::text('observations', $schedule->observations, ['class' => 'form-control' . ($errors->has('observations') ? ' is-invalid' : ''), 'placeholder' => 'Observaciones'])); ?>

            <?php echo $errors->first('observations', '<div class="invalid-feedback">:message</p>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <br>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </div>
</div><?php /**PATH D:\laragon\www\proyectogrado\resources\views/schedule/form.blade.php ENDPATH**/ ?>