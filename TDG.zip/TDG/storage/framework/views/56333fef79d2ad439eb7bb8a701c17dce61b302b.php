

<?php $__env->startSection('template_title'); ?>
    Horario Docentes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <div style="display: flex; justify-content: space-between; align-items: center;">

                            <span id="card_title">
                                <?php echo e(__('Horario Docentes')); ?>

                            </span>
                        </div>
                    </div>
                    <div class="card-body">
                        <span class="card-title"><b>Buscar docentes</b></span>
                        <form method="GET" action="<?php echo e(route('teachers.timetable')); ?>"  role="form">
                            <?php echo $__env->make('teacher.search_form_teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </form>
                    </div>

                    <?php if($schedules != null): ?>
                        <div class="row justify-content-center">
                            <div class="col-auto">
                                <table class="table table-responsive">
                                    <thead class="thead">
                                        <tr>
                                            <th>Nombre docente</th>                                            
                                            <th>Documento docente</th>                                            
                                            <th>Tipo Contrato</th>                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <td><?php echo e($teacher->name); ?></td>
                                        <td><?php echo e($teacher->document); ?></td>
                                        <td><?php echo e($teacher->contract_type); ?></td>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead class="thead">
                                        <tr>
                                            <th>Código</th>
                                            <th>Nombre asignatura</th>
                                            <th>Día</th>
                                            <th>Hora</th>
                                            <th>Groupo</th>
                                            <th>Aula</th>
                                            <th>Actividad</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($schedule->subject->subject_code); ?></td>
                                            <td><?php echo e($schedule->subject->subject_name); ?></td>
                                            <td><?php echo e($days[$schedule->day]); ?></td>
                                            <td><?php echo e($schedule->start_hour . ':' . $schedule->start_minute . '-' . $schedule->end_hour . ':' . $schedule->end_minute); ?></td>
                                            <td><?php echo e($schedule->group); ?></td>
                                            <td><?php echo e($schedule->classroom); ?></td>
                                            <td><?php echo e($schedule->activity); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>                
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\proyectogrado\resources\views/teacher/timetable.blade.php ENDPATH**/ ?>