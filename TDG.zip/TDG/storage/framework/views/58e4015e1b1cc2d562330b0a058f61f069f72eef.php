<?php $__env->startSection('template_title'); ?>
    <?php echo e($area->name ?? 'Información Área'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Información Área</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('areas.index')); ?>"> Atrás</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Nombre facultad:</strong>
                            <?php echo e($area->faculty->faculty_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre coordinación:</strong>
                            <?php echo e($area->coordination->coordination_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre programa:</strong>
                            <?php echo e($area->program->program_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre área:</strong>
                            <?php echo e($area->area_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre coordinador:</strong>
                            <?php echo e($area->user->name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Email coordinador:</strong>
                            <?php echo e($area->user->email); ?>

                        </div>
                        <div class="form-group">
                            <strong>Estado:</strong>
                            <?php echo e(($area->status == 1) ? 'Activo' : 'Inactivo'); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\proyectogrado\resources\views/area/show.blade.php ENDPATH**/ ?>