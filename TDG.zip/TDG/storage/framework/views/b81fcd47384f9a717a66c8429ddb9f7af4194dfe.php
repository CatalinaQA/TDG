<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('Nombre')); ?>

            <?php echo e(Form::text('name', $teacher->name, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Nombre'])); ?>

            <?php echo $errors->first('name', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Documento')); ?>

            <?php echo e(Form::text('document', $teacher->document, ['class' => 'form-control' . ($errors->has('document') ? ' is-invalid' : ''), 'placeholder' => 'Documento'])); ?>

            <?php echo $errors->first('document', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Email')); ?>

            <?php echo e(Form::text('email', $teacher->email, ['class' => 'form-control' . ($errors->has('email') ? ' is-invalid' : ''), 'placeholder' => 'Email'])); ?>

            <?php echo $errors->first('email', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Número telefónico')); ?>

            <?php echo e(Form::text('phone_number', $teacher->phone_number, ['class' => 'form-control' . ($errors->has('phone_number') ? ' is-invalid' : ''), 'placeholder' => 'Número telefónico'])); ?>

            <?php echo $errors->first('phone_number', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Número móvil')); ?>

            <?php echo e(Form::text('cellphone_number', $teacher->cellphone_number, ['class' => 'form-control' . ($errors->has('cellphone_number') ? ' is-invalid' : ''), 'placeholder' => 'Número móvil'])); ?>

            <?php echo $errors->first('cellphone_number', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Tipo de contrato')); ?>

            <?php echo e(Form::select('contract_type', ["Tiempo completo" => "Tiempo completo", "Catedra" => "Catedra"], $teacher->contract_type, ['class' => 'form-control' . ($errors->has('contract_type') ? ' is-invalid' : ''), 'placeholder' => 'Tipo de contrato'])); ?>

            <?php echo $errors->first('contract_type', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Estado')); ?>

            <?php echo e(Form::select('status', [1=>'Activo', 0=>'Inactivo'], ($teacher->status) ?? 1, ['class' => 'form-control' . ($errors->has('status') ? ' is-invalid' : ''), 'placeholder' => 'Estado'])); ?>

            <?php echo $errors->first('status', '<div class="invalid-feedback">:message</p>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <br>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </div>
</div>

<?php /**PATH D:\laragon\www\proyectogrado\resources\views/teacher/form.blade.php ENDPATH**/ ?>