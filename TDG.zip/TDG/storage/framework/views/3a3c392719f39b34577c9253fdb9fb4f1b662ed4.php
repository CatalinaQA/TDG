<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('Nombre')); ?>

            <?php echo e(Form::text('name', $user->name, ['class' => 'form-control' . ($errors->has('name') ? ' is-invalid' : ''), 'placeholder' => 'Nombre'])); ?>

            <?php echo $errors->first('name', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('email')); ?>

            <?php echo e(Form::text('email', $user->email, ['class' => 'form-control' . ($errors->has('email') ? ' is-invalid' : ''), 'placeholder' => 'Email'])); ?>

            <?php echo $errors->first('email', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('role')); ?>

            <?php echo e(Form::select('role', 
                [
                    'admin'                     => 'Admin',
                    'profesional especializado' => 'Profesional especializado',
                    'coordinador área'          => 'Coordinador área',
                    'decano'                    => 'Decano',
                    'docente'                   => 'Docente',
                    'admisiones'                => 'Admisiones'
                ], 
                $user->role, ['class' => 'form-control' . ($errors->has('role') ? ' is-invalid' : ''), 'placeholder' => 'Role'])); ?>

            <?php echo $errors->first('role', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Documento')); ?>

            <?php echo e(Form::text('document', $user->document, ['class' => 'form-control' . ($errors->has('document') ? ' is-invalid' : ''), 'placeholder' => 'Documento'])); ?>

            <?php echo $errors->first('document', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Celular')); ?>

            <?php echo e(Form::text('cellphone_number', $user->cellphone_number, ['class' => 'form-control' . ($errors->has('cellphone_number') ? ' is-invalid' : ''), 'placeholder' => 'Celular'])); ?>

            <?php echo $errors->first('cellphone_number', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('Tipo de contrato')); ?>

            <?php echo e(Form::select('contract_type', 
                ["Tiempo completo" => "Tiempo completo", "Catedra" => "Catedra", "Tiempo ocasional" => "Tiempo ocasional"], 
                $user->contract_type, ['class' => 'form-control' . ($errors->has('contract_type') ? ' is-invalid' : ''), 'placeholder' => 'Tipo de contrato'])); ?>

            <?php echo $errors->first('contract_type', '<div class="invalid-feedback">:message</p>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <br>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </div>
</div><?php /**PATH D:\laragon\www\proyectogrado\resources\views/user/form.blade.php ENDPATH**/ ?>