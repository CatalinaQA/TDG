<?php $__env->startSection('template_title'); ?>
    <?php echo e($schedule->name ?? 'Ver programación académica'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Ver programación académica</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('schedules.index')); ?>"> Atrás</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Sede:</strong>
                            <?php echo e($campus[$schedule->campus]); ?>

                        </div>
                        <div class="form-group">
                            <strong>Código:</strong>
                            <?php echo e($schedule->subject->subject_code); ?>

                        </div>
                        <div class="form-group">
                            <strong>Groupo:</strong>
                            <?php echo e($schedule->group); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre:</strong>
                            <?php echo e($schedule->subject->subject_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Detalle:</strong>
                            <?php echo e($schedule->detail); ?>

                        </div>
                        <div class="form-group">
                            <strong>Día:</strong>
                            <?php echo e($days[$schedule->day]); ?>

                        </div>
                        <div class="form-group">
                            <strong>Hora:</strong>
                            <?php echo e($schedule->start_hour . ':' . $schedule->start_minute . '-' . $schedule->end_hour . ':' . $schedule->end_minute); ?>

                        </div>
                        <div class="form-group">
                            <strong>Aula:</strong>
                            <?php echo e($schedule->classroom); ?>

                        </div>
                        <div class="form-group">
                            <strong>Actividad:</strong>
                            <?php echo e($schedule->activity); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nivel estudio:</strong>
                            <?php echo e($schedule->subject->subject_level); ?>

                        </div>
                        <div class="form-group">
                            <strong>Créditos:</strong>
                            <?php echo e($schedule->subject->credits); ?>

                        </div>
                        <div class="form-group">
                            <strong>Capacidad aula:</strong>
                            <?php echo e($schedule->classroom_capacity); ?>

                        </div>
                        <div class="form-group">
                            <strong>Capacidad programada:</strong>
                            <?php echo e($schedule->scheduled_capacity); ?>

                        </div>
                        <div class="form-group">
                            <strong>Matriculados:</strong>
                            <?php echo e($schedule->enrolled); ?>

                        </div>
                        <div class="form-group">
                            <strong>Programa:</strong>
                            <?php echo e($schedule->program->program_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Plan:</strong>
                            <?php echo e($schedule->plan); ?>

                        </div>
                        <div class="form-group">
                            <strong>Total horas:</strong>
                            <?php echo e($schedule->total_hours); ?>

                        </div>
                        <div class="form-group">
                            <strong>Asesorías:</strong>
                            <?php echo e($schedule->consultancies); ?>

                        </div>
                        <div class="form-group">
                            <strong>Horas evaluación:</strong>
                            <?php echo e($schedule->evaluation_hours); ?>

                        </div>
                        <div class="form-group">
                            <strong>Cédula:</strong>
                            <?php echo e(($schedule->teacher != "") ? $schedule->teachers->document : ""); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre:</strong>
                            <?php echo e(($schedule->teacher != "") ? $schedule->teachers->name : ""); ?>

                        </div>
                        <div class="form-group">
                            <strong>Tipo vinculación:</strong>
                            <?php echo e(($schedule->teacher != "") ? $schedule->teachers->contract_type : ""); ?>

                        </div>
                        <div class="form-group">
                            <strong>Área:</strong>
                            <?php echo e($schedule->area->area_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Coordinador:</strong>
                            <?php echo e($schedule->area->coordination_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Observaciones:</strong>
                            <?php echo e($schedule->observations); ?>

                        </div>
                        <div class="form-group">
                            <strong>Status:</strong>
                            <?php echo e($schedule->status); ?>

                        </div>
                        <div class="form-group">
                            <strong>Actualizado por:</strong>
                            <?php echo e(($schedule->user->name) ?? ""); ?>

                        </div>
                        <div class="form-group">
                            <strong>Fecha actualización:</strong>
                            <?php echo e(($schedule->updated_at) ?? ""); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\proyectogrado\resources\views/schedule/show.blade.php ENDPATH**/ ?>