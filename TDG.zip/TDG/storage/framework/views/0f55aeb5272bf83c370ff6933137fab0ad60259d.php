<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/jquery/jquery.min.js')); ?>"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <div id="app" style="background-color: darkgreen">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <img src="<?php echo e(asset('images/politecnico.jpeg')); ?>" alt="" style="height: auto;width: 80px;">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    Programación Academica
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">

                    <?php if(Auth::check()): ?>

                        <?php if(Auth::user()->role === 'admin' || Auth::user()->role === 'coordinador'): ?>
                            <ul class="navbar-nav me-auto">
                                <li class="nav-item dropdown">
                                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre><b>Usuarios</b></a>
                                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="<?php echo e(route('users.index')); ?>"><?php echo e(__('Lista de usuarios')); ?></a>
                                    </div>
                                </li>
                            </ul>
                        <?php endif; ?>
                            <ul class="navbar-nav me-auto">
                                <li class="nav-item dropdown">
                                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre><b>Información general</b></a>
                                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">                                        
                                        <a class="dropdown-item" href="<?php echo e(route('faculties.index')); ?>"><?php echo e(__('Facultades')); ?></a>
                                        <a class="dropdown-item" href="<?php echo e(route('coordinations.index')); ?>"><?php echo e(__('Coordinaciones')); ?></a>
                                        <a class="dropdown-item" href="<?php echo e(route('programs.index')); ?>"><?php echo e(__('Programas')); ?></a>
                                        <a class="dropdown-item" href="<?php echo e(route('areas.index')); ?>"><?php echo e(__('Áreas')); ?></a>
                                        <a class="dropdown-item" href="<?php echo e(route('subjects.index')); ?>"><?php echo e(__('Asignaturas')); ?></a>
                                    </div>
                                </li>
                            </ul>
                        <?php if(Auth::user()->role !== 'admisiones'): ?>
                            <ul class="navbar-nav me-auto">
                                <li class="nav-item dropdown">
                                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre><b>Docentes</b></a>
                                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="<?php echo e(route('teachers.index')); ?>"><?php echo e(__('Directorio docentes')); ?></a>
                                        <a class="dropdown-item" href="<?php echo e(route('teachers.payroll')); ?>"><?php echo e(__('Nómina')); ?></a>
                                        <a class="dropdown-item" href="<?php echo e(route('teachers.timetable')); ?>"><?php echo e(__('Horario docentes')); ?></a>
                                    </div>
                                </li>
                            </ul>
                        <?php endif; ?>
                            <ul class="navbar-nav me-auto">
                                <li class="nav-item dropdown">
                                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre><b>Archivos</b></a>
                                    <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                        <a class="dropdown-item" href="<?php echo e(route('load-periods.index')); ?>"><?php echo e(__('Cargar periodo')); ?></a>
                                    </div>
                                </li>
                            </ul>
                            <ul class="navbar-nav me-auto">
                                <a class="nav-link" href="<?php echo e(route('schedules.index')); ?>"><b><?php echo e(__('Programación académica')); ?></b></a>
                            </ul>
                        
                    <!-- Left Side Of Navbar -->
                    

                    <?php endif; ?>
                    

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>
<!--
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
-->
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('auth.change_password')); ?>"><?php echo e(__('Cambiar contraseña')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\proyectogrado\resources\views/layouts/app.blade.php ENDPATH**/ ?>