<div class="row g-3">
    <div class="col-sm-4">
        <?php echo e(Form::text('faculty_name', $request['faculty_name'], ['class' => 'form-control', 'placeholder' => 'Nombre facultad'])); ?>

    </div>
    <div class="col-sm">
        <?php echo e(Form::text('dean_name', $request['dean_name'], ['class' => 'form-control', 'placeholder' => 'Nombre decano'])); ?>

    </div>
    <div class="col-sm">
        <button type="submit" class="btn btn-primary">Buscar</button>
    </div>
</div><?php /**PATH C:\xampp\htdocs\TDG\TDG\resources\views/faculty/search_form.blade.php ENDPATH**/ ?>