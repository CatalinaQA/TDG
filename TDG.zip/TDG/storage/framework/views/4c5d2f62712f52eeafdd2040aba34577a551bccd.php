<?php $__env->startSection('template_title'); ?>
    <?php echo e($faculty->name ?? 'Información Facultad'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Información Facultad</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('faculties.index')); ?>"> Atrás</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Nombre:</strong>
                            <?php echo e($faculty->faculty_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre decano:</strong>
                            <?php echo e($faculty->user->name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Email decano:</strong>
                            <?php echo e($faculty->user->email); ?>

                        </div>
                        <div class="form-group">
                            <strong>Teléfono:</strong>
                            <?php echo e($faculty->dean_phone); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre auxiliar:</strong>
                            <?php echo e($faculty->faculty_auxiliar_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Email auxiliar:</strong>
                            <?php echo e($faculty->faculty_auxiliar_email); ?>

                        </div>
                        <div class="form-group">
                            <strong>Teléfono auxiliar:</strong>
                            <?php echo e($faculty->faculty_auxiliar_phone); ?>

                        </div>
                        <div class="form-group">
                            <strong>Estado:</strong>
                            <?php echo e(($faculty->status == 1) ? 'Activo' : 'Inactivo'); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\proyectogrado\resources\views/faculty/show.blade.php ENDPATH**/ ?>