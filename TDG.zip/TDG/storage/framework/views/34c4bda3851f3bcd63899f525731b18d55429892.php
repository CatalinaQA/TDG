<?php $__env->startSection('template_title'); ?>
    <?php echo e($coordination->name ?? 'Información Coordinación'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="content container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="float-left">
                            <span class="card-title">Información Coordinación</span>
                        </div>
                        <div class="float-right">
                            <a class="btn btn-primary" href="<?php echo e(route('coordinations.index')); ?>"> Atrás</a>
                        </div>
                    </div>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <strong>Nombre facultad:</strong>
                            <?php echo e($coordination->faculty->faculty_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre coordinación:</strong>
                            <?php echo e($coordination->coordination_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre profesional:</strong>
                            <?php echo e($coordination->user->name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Email profesional:</strong>
                            <?php echo e($coordination->user->email); ?>

                        </div>
                        <div class="form-group">
                            <strong>Teléfono:</strong>
                            <?php echo e($coordination->professional_phone); ?>

                        </div>
                        <div class="form-group">
                            <strong>Nombre auxiliar:</strong>
                            <?php echo e($coordination->coordination_auxiliar_name); ?>

                        </div>
                        <div class="form-group">
                            <strong>Email auxiliar:</strong>
                            <?php echo e($coordination->coordination_auxiliar_email); ?>

                        </div>
                        <div class="form-group">
                            <strong>Teléfono auxiliar:</strong>
                            <?php echo e($coordination->coordination_auxiliar_phone); ?>

                        </div>
                        <div class="form-group">
                            <strong>Estado:</strong>
                            <?php echo e(($coordination->status == 1) ? 'Activo' : 'Inactivo'); ?>

                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\proyectogrado\resources\views/coordination/show.blade.php ENDPATH**/ ?>