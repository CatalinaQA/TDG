<div class="box box-info padding-1">
    <div class="box-body">
        
        <div class="form-group">
            <?php echo e(Form::label('faculty_id')); ?>

            <?php echo e(Form::select('faculty_id', $faculties, $curriculumMatrix->faculty_id, ['class' => 'form-control' . ($errors->has('faculty_id') ? ' is-invalid' : ''), 'placeholder' => 'Faculty Id'])); ?>

            <?php echo $errors->first('faculty_id', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('coordination_id')); ?>

            <?php echo e(Form::select('coordination_id', $coordinations, $curriculumMatrix->coordination_id, ['class' => 'form-control' . ($errors->has('coordination_id') ? ' is-invalid' : ''), 'placeholder' => 'Coordination Id'])); ?>

            <?php echo $errors->first('coordination_id', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('program_id')); ?>

            <?php echo e(Form::select('program_id', $programs, $curriculumMatrix->program_id, ['class' => 'form-control' . ($errors->has('program_id') ? ' is-invalid' : ''), 'placeholder' => 'Program Id'])); ?>

            <?php echo $errors->first('program_id', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('course_name')); ?>

            <?php echo e(Form::text('course_name', $curriculumMatrix->course_name, ['class' => 'form-control' . ($errors->has('course_name') ? ' is-invalid' : ''), 'placeholder' => 'Course Name'])); ?>

            <?php echo $errors->first('course_name', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('course_credits')); ?>

            <?php echo e(Form::text('course_credits', $curriculumMatrix->course_credits, ['class' => 'form-control' . ($errors->has('course_credits') ? ' is-invalid' : ''), 'placeholder' => 'Course Credits'])); ?>

            <?php echo $errors->first('course_credits', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('course_level')); ?>

            <?php echo e(Form::text('course_level', $curriculumMatrix->course_level, ['class' => 'form-control' . ($errors->has('course_level') ? ' is-invalid' : ''), 'placeholder' => 'Course Level'])); ?>

            <?php echo $errors->first('course_level', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('prerequisite_code_1')); ?>

            <?php echo e(Form::text('prerequisite_code_1', $curriculumMatrix->prerequisite_code_1, ['class' => 'form-control' . ($errors->has('prerequisite_code_1') ? ' is-invalid' : ''), 'placeholder' => 'Prerequisite Code 1'])); ?>

            <?php echo $errors->first('prerequisite_code_1', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('prerequisite_name_1')); ?>

            <?php echo e(Form::text('prerequisite_name_1', $curriculumMatrix->prerequisite_name_1, ['class' => 'form-control' . ($errors->has('prerequisite_name_1') ? ' is-invalid' : ''), 'placeholder' => 'Prerequisite Name 1'])); ?>

            <?php echo $errors->first('prerequisite_name_1', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('prerequisite_code_2')); ?>

            <?php echo e(Form::text('prerequisite_code_2', $curriculumMatrix->prerequisite_code_2, ['class' => 'form-control' . ($errors->has('prerequisite_code_2') ? ' is-invalid' : ''), 'placeholder' => 'Prerequisite Code 2'])); ?>

            <?php echo $errors->first('prerequisite_code_2', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('prerequisite_name_2')); ?>

            <?php echo e(Form::text('prerequisite_name_2', $curriculumMatrix->prerequisite_name_2, ['class' => 'form-control' . ($errors->has('prerequisite_name_2') ? ' is-invalid' : ''), 'placeholder' => 'Prerequisite Name 2'])); ?>

            <?php echo $errors->first('prerequisite_name_2', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('corequisite_code_1')); ?>

            <?php echo e(Form::text('corequisite_code_1', $curriculumMatrix->corequisite_code_1, ['class' => 'form-control' . ($errors->has('corequisite_code_1') ? ' is-invalid' : ''), 'placeholder' => 'Corequisite Code 1'])); ?>

            <?php echo $errors->first('corequisite_code_1', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('corequisite_name_1')); ?>

            <?php echo e(Form::text('corequisite_name_1', $curriculumMatrix->corequisite_name_1, ['class' => 'form-control' . ($errors->has('corequisite_name_1') ? ' is-invalid' : ''), 'placeholder' => 'Corequisite Name 1'])); ?>

            <?php echo $errors->first('corequisite_name_1', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('corequisite_code_2')); ?>

            <?php echo e(Form::text('corequisite_code_2', $curriculumMatrix->corequisite_code_2, ['class' => 'form-control' . ($errors->has('corequisite_code_2') ? ' is-invalid' : ''), 'placeholder' => 'Corequisite Code 2'])); ?>

            <?php echo $errors->first('corequisite_code_2', '<div class="invalid-feedback">:message</p>'); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('corequisite_name_2')); ?>

            <?php echo e(Form::text('corequisite_name_2', $curriculumMatrix->corequisite_name_2, ['class' => 'form-control' . ($errors->has('corequisite_name_2') ? ' is-invalid' : ''), 'placeholder' => 'Corequisite Name 2'])); ?>

            <?php echo $errors->first('corequisite_name_2', '<div class="invalid-feedback">:message</p>'); ?>

        </div>

    </div>
    <div class="box-footer mt20">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</div><?php /**PATH D:\laragon\www\proyectogrado\resources\views/curriculum_matrix/form.blade.php ENDPATH**/ ?>